// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import LoginScreen from '../LoginScreen';
// import Whisper from '../Whisper';


// const Stack = createNativeStackNavigator();

// const HomeStack = () => {
//   return (
//     <Stack.Navigator>
//       <Stack.Screen
//         name="home"
//         component={Whisper}
//         options={{ headerShown: false }}
        
//       />
//        <Stack.Screen
//         name="login"
//         component={LoginScreen}
//         options={{ headerShown: false }}
        
//       />
    
//     </Stack.Navigator>
//   );
// };

// export default HomeStack;