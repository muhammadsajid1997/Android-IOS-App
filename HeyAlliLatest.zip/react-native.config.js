// module.exports={
// assets:["./assets/fonts"]
// }

module.exports = {
  dependencies: {
    'react-native-vector-icons': {
      platforms: {
        ios: {},
      },
    },
  },
  assets: ["./assets/Fonts"],
};